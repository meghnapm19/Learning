import React, { useState, useEffect } from 'react';
import logo from './logo.svg';
import './App.css';
import UserPage from './UserPage'; //Import the UserPage.js


function App()
{
    return (
    <div>
    <UserPage/>
    </div>
    )
}
export default App;
